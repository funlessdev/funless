function main() {
	console.log("hello world")
}

module.exports.main = main
